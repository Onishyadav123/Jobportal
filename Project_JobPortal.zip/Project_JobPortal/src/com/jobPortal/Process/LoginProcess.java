package com.jobPortal.Process;

import java.io.IOException;
import java.util.Iterator;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.Registration;
@WebServlet(urlPatterns = "/LoginProcess")
public class LoginProcess  extends HttpServlet{
	 public  String name;
	  HttpSession sessioncheck;
	  public  int x=0;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 String password=req.getParameter("password");
	 String email= req.getParameter("email");
	
	 
	 Configuration configuration=ConnectionDao.getConnnConnectionDao();
		configuration.configure("hibernate.cfg.xml");
		 Session session=configuration.buildSessionFactory().openSession();
		  Transaction transaction=session.beginTransaction();
		 Registration r= new Registration();
		 org.hibernate.Query<Registration> query = session.createQuery("from Registration");
	        java.util.List list = query.list();
	        
	   Iterator<Registration> i=list.iterator();
	   while(i.hasNext()) {
		   Registration registration= i.next();
		 if(email.equalsIgnoreCase(registration.getEmail())&&password.equals(registration.getPassword())) {
			 HttpSession s1= req.getSession();
			 
			  name=registration.getName();
			 email=registration.getEmail();
		
	
			 if(registration.getRole().equalsIgnoreCase("Student")) {
					s1.setAttribute("email", email);
					s1.setAttribute("id" ,	registration.getResid());
					
					s1.setAttribute("name",registration.getName());
			 resp.sendRedirect("StudentHome.jsp");
			 }else if (registration.getRole().equalsIgnoreCase("Recruiter")){
					s1.setAttribute("email",registration.getEmail());
					s1.setAttribute("id" ,	registration.getResid());
					
					s1.setAttribute("name",registration.getName());
				 resp.sendRedirect("RecruiterHome.jsp");}
			 }
			
		 }
	   req.getRequestDispatcher("LoginFail.jsp").include(req, resp);
	   }
	  
	  
}

