package com.jobPortal.Process;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.Registration;

@WebServlet(urlPatterns = "/Forget")
public class ForgetPassword extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	    String role=req.getParameter("role");
		 String email=req.getParameter("email");
		 String password=req.getParameter("password");
		 Configuration configuration=ConnectionDao.getConnnConnectionDao();
			configuration.configure("hibernate.cfg.xml");
			 Session session=configuration.buildSessionFactory().openSession();
			  Transaction transaction=session.beginTransaction();
			
			 org.hibernate.Query<Registration> query = session.createQuery("from Registration");
		        java.util.List list = query.list();
		        
		   Iterator<Registration> i=list.iterator();
		   while(i.hasNext()) {
			   Registration registration= i.next();
			 if(email.equalsIgnoreCase(registration.getEmail())&&role.equals(registration.getRole())) {
				 registration.setEmail(email);
				 registration.setPassword(password);
				 registration.setRole(role);
				 registration.setName(registration.getName());
				
				 session.update(registration);
				 
			
				 req.getRequestDispatcher("register.jsp").include(req, resp);
			 }
			   
		   }
		  
	}
}
