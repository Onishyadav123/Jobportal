package com.jobPortal.Process;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet(urlPatterns = "/ProfileCheck")
public class ProfileCheck extends HttpServlet {
	 static int  x;
	 
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			doGet(req, resp);
		}
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	HttpSession s1=req.getSession(false);
	//System.out.println(s1.getAttribute("name").toString());
	if(s1!=null) {
		
		req.getRequestDispatcher("WholeProfile.jsp").forward(req, resp);
		
				}else { 
					
					resp.setContentType("text/html");
				 resp.getWriter().print("<h3>Please Login First</h3>");
					req.getRequestDispatcher("register.jsp").include(req, resp);
		}
		
	}
}
