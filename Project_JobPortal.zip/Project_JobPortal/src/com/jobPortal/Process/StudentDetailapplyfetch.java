package com.jobPortal.Process;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.StudentAppliedDetail;

public class StudentDetailapplyfetch extends HttpServlet {
	
	List list=new ArrayList();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Configuration configuration=ConnectionDao.getConnnConnectionDao();
		configuration.configure("hibernate.cfg.xml");
		 Session session=configuration.buildSessionFactory().openSession();
		  Transaction transaction=session.beginTransaction();
		    Criteria c=session.createCriteria(StudentAppliedDetail.class);
		     List l=c.list();
		     
		      Iterator<StudentAppliedDetail> i=l.iterator();
		    while (i.hasNext()) {
		    	list.add(i.next().getName());
		    	
		    }
		      
		      req.setAttribute("list",list);
		      req.getRequestDispatcher("Studentlist.jsp").forward(req, resp);
		      
	}

}
