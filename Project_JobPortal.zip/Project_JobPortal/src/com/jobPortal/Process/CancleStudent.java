package com.jobPortal.Process;

import java.awt.List;
import java.io.IOException;
import java.util.ArrayList;

import javax.management.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.StudentAppliedDetail;
@WebServlet(urlPatterns ="/CancleStudent")
public class CancleStudent extends HttpServlet {
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	List list=new List();
	Session session1;
int id= Integer.parseInt(  req.getParameter("id"));
	Configuration configuration=ConnectionDao.getConnnConnectionDao();
	configuration.configure("hibernate.cfg.xml");
	 session1=configuration.buildSessionFactory().openSession();
	 Transaction transaction=session1.beginTransaction();
	   Criteria c=session1.createCriteria(StudentAppliedDetail.class);
	  StudentAppliedDetail s=(StudentAppliedDetail)session1.get(StudentAppliedDetail.class,id);
//System.out.println(req.getParameter("id"));
	session1.delete(s);
	 
	transaction.commit();
	   
	   
	   
	   
	   
	 	   
	 
	   req.getRequestDispatcher("PostedJob.jsp").forward(req, resp);
	}
}
