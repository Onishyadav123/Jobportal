package com.jobPortal.Process;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.StudentAppliedDetail;
@WebServlet(urlPatterns = "/StudentResume")
public class StudentResume  extends HttpServlet{
	private String name;
	private String projects;
	private String skills;
	private String gender;
	private String address;
	private String highschool;
	private String intermediate;
	private String email;
	private String qualification;
	private String post;
	private String experience;
	private String remail;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 name=req.getParameter("name");
	 projects=req.getParameter("projects");
	 skills=req.getParameter("skills");
	 gender=req.getParameter("gender");
	 address=req.getParameter("address");
	 highschool=req.getParameter("highschool");
	 intermediate=req.getParameter("intermediate");
	experience=req.getParameter("experience");
	 email=req.getParameter("email");
	 qualification=req.getParameter("qualification");
	post=req.getParameter("post");
	remail=req.getParameter("remail");
	Configuration configuration=ConnectionDao.getConnnConnectionDao();
	configuration.configure("hibernate.cfg.xml");
	 Session session=configuration.buildSessionFactory().openSession();
	  Transaction transaction=session.beginTransaction();
	  
	  StudentAppliedDetail s= new StudentAppliedDetail();
	  s.setName(name);
	  s.setAddress(address);
	  s.setEmail(email);
	  s.setGender(gender);
	  s.setHighschool(highschool);
	  s.setIntermediate(intermediate);
s.setExperience(experience);
	  s.setProjects(projects);
	  s.setQualification(qualification);
	  s.setSkills(skills);
	  s.setPost(post);
	  s.setRemail(remail);
	  session.save(s);
	  transaction.commit();
	  System.out.println("success"+remail);
	  req.getRequestDispatcher("Jobs.jsp").forward(req, resp);
	}
}
