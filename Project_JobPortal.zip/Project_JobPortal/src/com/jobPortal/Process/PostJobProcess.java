package com.jobPortal.Process;

import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileItem;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.Job;
import com.jobPortal.Models.Registration;

@WebServlet(urlPatterns = "/PostJobProcess")
public class PostJobProcess extends HttpServlet{
	private String company_name;
	private String post;
	private String salary;
	private String place;
	private String description;
	private String stream;
	private String email;
	private String qualification;
	private String upload_photo;
	private String name;
	private String department;
	
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 HttpSession s1= req.getSession( false);
    // name= s1.getAttribute(name).toString();
     if(s1!=null) {
    	 System.out.println(s1.getId());
	company_name=req.getParameter("company_name");
	department=req.getParameter("department");
	post=req.getParameter("Post"); 
	salary=req.getParameter("salary");
	stream=req.getParameter("Stream");
	place=req.getParameter("place");
	email=req.getParameter("Email Address");
qualification=req.getParameter("qualification");
description=req.getParameter("description");
upload_photo=req.getParameter("upload_photo");

Configuration configuration=ConnectionDao.getConnnConnectionDao();
configuration.configure("hibernate.cfg.xml");
 Session session=configuration.buildSessionFactory().openSession();
  Transaction transaction=session.beginTransaction();
 Job j= new Job();
 j.setCompany_name(company_name);
 j.setDescription(description);
 j.setEmail(email);
 j.setPlace(place);
 j.setPost(post);
 j.setQualification(qualification);
 j.setSalary(salary);
 j.setStream(stream);
 j.setUpload_photo(upload_photo);
 j.setDepartment(department);
 session.save(j);
 transaction.commit();
 
 System.out.println("sucess");
 resp.setContentType("text/html");
 resp.getWriter().print("<h3>Successfull</h3>");
 resp.sendRedirect("PostaJob.jsp");
     }else {
    	 resp.getWriter().print("<h3>Please login First</h3>");
    	 req.getRequestDispatcher("register.jsp");
     }
}
}
