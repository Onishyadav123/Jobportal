package com.jobPortal.Process;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.Registration;
@WebServlet(urlPatterns = "/RegisterProcess")
public class RegistrationProcess  extends HttpServlet{
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 String name=req.getParameter("name");
	 String password=req.getParameter("password");
	 String email= req.getParameter("email");
	String  role=req.getParameter("role");
	
	Configuration configuration=ConnectionDao.getConnnConnectionDao();
	configuration.configure("hibernate.cfg.xml");
	 Session session=configuration.buildSessionFactory().openSession();
	  Transaction transaction=session.beginTransaction();
	 Registration r= new Registration();
	 r.setEmail(email);
	 r.setName(name);
	 r.setPassword(password);
	 r.setRole(role);
	 session.save(r);
	 transaction.commit();
	 
	
	 
	
	req.getRequestDispatcher("register.jsp").include(req, resp);
	 
	 
	 
}
}
