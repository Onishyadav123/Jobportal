package com.jobPortal.Process;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
@WebServlet(urlPatterns = "/LogOut")
public class LogoutProcess extends HttpServlet {
private String name;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	  doGet(req, resp);
    
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	 HttpSession s= req.getSession( false);
    
 //																					   s.removeAttribute("name");
    s.removeValue("name");
   s.removeAttribute("id");
   s.removeValue("email");
   s.removeValue("id");
     s.removeAttribute("email");
     s.invalidate();
     resp.sendRedirect("register.jsp");
	}
}
