package com.jobPortal.Process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.Job;
import com.jobPortal.Models.Registration;
@WebServlet(urlPatterns = "/search")
public class SearchQuery  extends HttpServlet{
	
	private String stream;
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 stream=  req.getParameter("stream");
		 System.out.println(stream);
		 Configuration configuration=ConnectionDao.getConnnConnectionDao();
			configuration.configure("hibernate.cfg.xml");
			 Session session=configuration.buildSessionFactory().openSession();
			  Transaction transaction=session.beginTransaction();
			  req.setAttribute("stream", stream);
				 
				 
				 req.getRequestDispatcher("searchDisplay.jsp").include(req, resp);
		/*	 org.hibernate.Query<Registration> query = session.createQuery("from Job");
		        java.util.List list = query.list();
		        
		   Iterator<Job> i=list.iterator();
		   while(i.hasNext()) {
			  Job job= i.next();
			 if(stream.equalsIgnoreCase(job.getStream())||stream.equalsIgnoreCase(job.getPlace())||stream.equalsIgnoreCase(job.getQualification())||stream.equalsIgnoreCase(job.getCompany_name())){
				req.setAttribute("stream", stream);
				 
				 
				 req.getRequestDispatcher("searchDisplay.jsp").include(req, resp);
}	}*/
}}
