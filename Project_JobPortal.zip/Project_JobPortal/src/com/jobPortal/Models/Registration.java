package com.jobPortal.Models;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

@Entity
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "Registration")
public class Registration {
private String name;
@Id
@GeneratedValue(strategy = GenerationType.AUTO)

private int resid;


private String email;
private String password;
private String role;

private String company;
public String getCompany() {
	return company;
}
public void setCompany(String company) {
	this.company = company;
}
private String profession;
private String gender;

private String upload_photo;
private String department;
private String address;

private String languages;


public String getLanguages() {
	return languages;
}
public void setLanguages(String languages) {
	this.languages = languages;
}
private String father;
private String mother;
private String dob;
//private String permanent;
private String radios_status;
private String phoneno ;


public String getProfession() {
	return profession;
}
public void setProfession(String profession) {
	this.profession = profession;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getUpload_photo() {
	return upload_photo;
}
public void setUpload_photo(String upload_photo) {
	this.upload_photo = upload_photo;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getFather() {
	return father;
}
public void setFather(String father) {
	this.father = father;
}
public String getMother() {
	return mother;
}
public void setMother(String mother) {
	this.mother = mother;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getRadios_status() {
	return radios_status;
}
public void setRadios_status(String radios_status) {
	this.radios_status = radios_status;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getResid() {
	return resid;
}
public void setResid(int resid) {
	this.resid = resid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
