package com.jobPortal.Models;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cacheable
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "recruiterprofile")
public class ProfileDetailRecruiter {
private String name;
private String company_name;
private String profession;
private String gender;
private String email;
private String upload_photo;
private String department;
private String address;
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int id;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getCompany_name() {
	return company_name;
}
public void setCompany_name(String company_name) {
	this.company_name = company_name;
}
public String getProfession() {
	return profession;
}
public void setProfession(String profession) {
	this.profession = profession;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getUpload_photo() {
	return upload_photo;
}
public void setUpload_photo(String upload_photo) {
	this.upload_photo = upload_photo;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
}
