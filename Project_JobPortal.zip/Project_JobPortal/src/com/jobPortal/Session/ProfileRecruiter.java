package com.jobPortal.Session;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
@WebServlet(urlPatterns = "/ProfileRecruiter")
public class ProfileRecruiter extends HttpServlet {
	private String email;
	private String gender;
	private String company;
	private String department;
	private String dob;
	//private String permanent;
	private String radios_status;
	private String phoneno ;
	
	//private String languages ;
	private String upload_photo ;
	int x=0;
	private String profession;
	private String address;
private String name;
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s= req.getSession(false);
	
	int id=	 Integer.parseInt(req.getParameter("id").toString());
		//System.out.println(emailcheck);
		 if (s!=null) {
			company=req.getParameter("company");
			 department=req.getParameter("department");
			 name=req.getParameter("name");
			radios_status=req.getParameter("radios_status");
			email=req.getParameter("email");
			phoneno=req.getParameter("phoneno");
			upload_photo=req.getParameter("upload_photo");
			address=req.getParameter("address");
			
			//languages=req.getParameter("language");
			dob=req.getParameter("dob");
			gender=req.getParameter("gender");
			profession=req.getParameter("profession");

			Configuration configuration=ConnectionDao.getConnnConnectionDao();
			configuration.configure("hibernate.cfg.xml");
			 Session session=configuration.buildSessionFactory().openSession();
		 Transaction transaction=session.beginTransaction();

Query query = session.createQuery("update Registration set name=:name,phoneno=:phoneno,company=:company,department=:department,upload_photo=:upload_photo,address=:address,gender=:gender,dob=:dob,profession=:profession" +
    				" where resid= :id");
query.setParameter("name",name);
query.setParameter("id",id);
query.setParameter("address",address);
query.setParameter("dob",dob);
//query.setParameter("languages",languages);
query.setParameter("gender",gender);
query.setParameter("profession",profession);
query.setParameter("upload_photo",upload_photo);
query.setParameter("phoneno",phoneno);
query.setParameter("company",company);
query.setParameter("department",department);

int result = query.executeUpdate();
		 
			
			 
				  
	
			  
		
			 
				req.getRequestDispatcher("RecruiterProfile.jsp").include(req, resp);
			 
			
		}else {
		 
			req.getRequestDispatcher("register.jsp").include(req, resp);
	}

}}
