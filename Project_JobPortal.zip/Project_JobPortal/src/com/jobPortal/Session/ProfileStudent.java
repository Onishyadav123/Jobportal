package com.jobPortal.Session;

import java.io.IOException;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.ProfileDetail;
import com.jobPortal.Models.Registration;
@WebServlet(urlPatterns = "/ProfileStudent")
public class ProfileStudent extends HttpServlet{
	private String name;
	private String email;
	private String gender;
	private String father;
	private String mother;
	private String dob;
	//private String permanent;
	private String radios_status;
	private String phoneno ;
	
	private String languages ;
	private String upload_photo ;
	int x=0;
	private String profession;
	private String address;

	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession s= req.getSession(false);
	
	int id=	 Integer.parseInt(req.getParameter("id").toString());
		//System.out.println(emailcheck);
		 if (s!=null) {
			 father=req.getParameter("father");
			 mother=req.getParameter("mother");
			 name=req.getParameter("name");
			radios_status=req.getParameter("radios_status");
			email=req.getParameter("email");
			phoneno=req.getParameter("phoneno");
			upload_photo=req.getParameter("upload_photo");
			address=req.getParameter("address");
			
			languages=req.getParameter("language");
			dob=req.getParameter("dob");
			gender=req.getParameter("gender");
			profession=req.getParameter("profession");

			Configuration configuration=ConnectionDao.getConnnConnectionDao();
			configuration.configure("hibernate.cfg.xml");
			 Session session=configuration.buildSessionFactory().openSession();
		 Transaction transaction=session.beginTransaction();

Query query = session.createQuery("update Registration set name=:name,phoneno=:phoneno, radios_status=:radios_status,upload_photo=:upload_photo, father=:father,mother=:mother,address=:address,languages=:languages,gender=:gender,dob=:dob,profession=:profession" +
    				" where resid= :id");
query.setParameter("name",name);
query.setParameter("id",id);
query.setParameter("address",address);
query.setParameter("dob",dob);
query.setParameter("languages",languages);
query.setParameter("gender",gender);
query.setParameter("profession",profession);
query.setParameter("upload_photo",upload_photo);
query.setParameter("phoneno",phoneno);
query.setParameter("father",father);
query.setParameter("mother",mother);
query.setParameter("radios_status",radios_status);
int result = query.executeUpdate();
		 
			
			 
				  
	
			  
			
			 
				req.getRequestDispatcher("StudentProfile.jsp").include(req, resp);
			 
			
		}else {
		 
			req.getRequestDispatcher("register.jsp").include(req, resp);
	}

}}