package com.jobPortal.SendMail;



import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.jobPortal.Dao.ConnectionDao;
import com.jobPortal.Models.ProfileDetail;
@WebServlet(urlPatterns = "/sendmail")
public class SendMail  extends HttpServlet{
	
	private String email; 
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doGet(req, resp);
	
	
}
@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	HttpSession hs= req.getSession(false);
int id=Integer.parseInt(	hs.getAttribute("id").toString());

Configuration configuration=ConnectionDao.getConnnConnectionDao();
	configuration.configure("hibernate.cfg.xml");
	 org.hibernate.Session session=configuration.buildSessionFactory().openSession();
	  Transaction transaction=session.beginTransaction();
 ProfileDetail p=	  session.get(ProfileDetail.class, id);
 
	email=p.getEmail();	
	
	
	//System.out.println(email+);
	String delivername=req.getParameter("name");
	String mobile =req.getParameter("phoneno");
	
	
	
	
	if( hs!=null){
	
	
	 String to = email;
	    String subject = "Confirmation Mail ";
	    String msg ="Name"+delivername+"MObile"+mobile;
	    final String from ="onishyadav@gmail.com";
	    final  String password ="";


	    Properties props = new Properties();  
	    props.setProperty("mail.transport.protocol", "smtp");     
	    props.setProperty("mail.host", "smtp.gmail.com");  
	    props.put("mail.smtp.auth", "true");  
	    props.put("mail.smtp.port", "465");  
	    props.put("mail.debug", "true");  
	    props.put("mail.smtp.socketFactory.port", "465");  
	    props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");  
	    props.put("mail.smtp.socketFactory.fallback", "false");  
	    Session session2 = Session.getDefaultInstance(props,  
	    new javax.mail.Authenticator() {
	       protected PasswordAuthentication getPasswordAuthentication() {  
	       return new PasswordAuthentication(from,password);  
	   }  
	   });  

	   //session.setDebug(true);  
	    try {
			
	
	   Transport transport = session2.getTransport();  
	   InternetAddress addressFrom = new InternetAddress(from);  

	   MimeMessage message = new MimeMessage(session2);  
	   message.setSender(addressFrom);  
	   message.setSubject(subject);  
	   message.setContent(msg, "text/plain");  
	   message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));  

	   transport.connect();  
	   Transport.send(message);  
	   req.getRequestDispatcher("PostedJob.jsp").forward(req, resp);
	   
	   
	   transport.close();	} catch (Exception e) {
			// TODO: handle exception
		}
	    
	}else{
		
		req.getRequestDispatcher("register.jsp").forward(req, resp);}
	   }  
	

	
	
}
